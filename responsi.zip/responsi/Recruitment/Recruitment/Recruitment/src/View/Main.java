package View;

import View.Recruitment.*;

//123220154_YogaSamudra_responsi
public class Main {

    public static void main(String[] args) {
        new ViewData();
    }
    
}
